import Link from "next/link";
import { Instagram, Mail, Pin } from "lucide-react";
import { site } from "@/lib/site";

export function Footer() {
  return (
    <footer className="mt-24 border-t border-black/5 bg-linen py-12 dark:border-white/10 dark:bg-[#201d1a]">
      <div className="container-premium grid gap-10 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <Link href="/" className="font-serif text-3xl text-ink dark:text-linen">
            Vikore Vana
          </Link>
          <p className="mt-4 max-w-sm text-sm leading-7 text-smoke dark:text-bone">
            Curated interiors, small-space ideas, and affiliate furniture edits for a calmer, more beautiful home.
          </p>
        </div>
        <div>
          <p className="mb-4 text-xs font-semibold uppercase tracking-[0.22em] text-cedar">Explore</p>
          <div className="grid gap-3">
            {site.nav.map((item) => (
              <Link key={item.href} href={item.href} className="text-sm text-smoke hover:text-ink dark:text-bone dark:hover:text-white">
                {item.label}
              </Link>
            ))}
          </div>
        </div>
        <div>
          <p className="mb-4 text-xs font-semibold uppercase tracking-[0.22em] text-cedar">Social</p>
          <div className="flex gap-3">
            {[Instagram, Pin, Mail].map((Icon, index) => (
              <span key={index} className="grid size-11 place-items-center rounded-full bg-white text-ink shadow-sm dark:bg-white/10 dark:text-linen">
                <Icon size={18} />
              </span>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
